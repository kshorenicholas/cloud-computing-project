<?php
    $servername = "localhost";
    $database = "main_db";
    $username = "kshore";
    $password = "pass123";

    $dbconn =  mysqli_connect($servername, $username, $password, $database);

    $query = "SELECT item_name FROM inventory_table";
    $result = $dbconn->query($query);
    $resultCheck = mysqli_num_rows($result);
    if($resultCheck > 0)
    {
        $options=mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    mysqli_free_result($result);
    $dbconn->close();       
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Delete Inventory</title>
        <link rel="stylesheet" href="./css/styles.css">
    </head>

    <body>
        <div id="header" class="mainHeader">
            <hr>
            <div class="center">Delete Existing Inventory</div>
        </div>
        <br>

        <div id="mainContent">
            <hr>
            <div></div>
        </div>

        <div>
            <form method="post">
                <br>
                <label for="inventory-group">Name of Inventory: </label> 
                <select name="item_name">
                    <option>Select Item</option>
                    <?php foreach($options as $option) { ?>
                    <option><?php echo $option['item_name']; ?></option>
                    <?php } ?>
                </select>
                <button type="submit" name="delete_button" value="Delete">Delete Item from Database</button>
            </form>
        </div>
        <?php
            if(isset($_POST['item_name']) && isset($_POST['delete_button']))
            {
                $servername = "localhost";
                $database = "main_db";
                $username = "kshore";
                $password = "pass123";
            
                $dbconn =  mysqli_connect($servername, $username, $password, $database);

                $item_name = $_POST['item_name'];
                $sql = "DELETE FROM inventory_table WHERE item_name='$item_name'";
                $result2 = $dbconn->query($sql);
                if (!$result2) 
                {
                    die("Error in SQL query: " . mysqli_connect_error());
                }
                
                $dbconn->close();
            } 
        ?>
        <br><br>
        <a href="view_inventory_webpage.php">Check Inventory amounts here</a>
    </body>
</html>