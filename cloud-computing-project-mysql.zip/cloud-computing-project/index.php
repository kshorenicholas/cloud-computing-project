<!DOCTYPE html>
<html>
<head>
	<meta charset="ISO-8859-1">
	<title>Inventory Management System!</title>
	<link rel="stylesheet" href="css/styles.css">
</head>

<body class="bodyStyle">

	<div id="header" class="mainHeader">
		<hr>
		<div class="center">Inventory Management System</div>
	</div>
	<br>

	<div id="mainContent">
		<hr>
		<div id="mainPictures" class="center">
			<table>
				<tr>
					<td><img src="images/multiple-stationaries_1.jpeg" height=auto width="490"></td>
					<td><img src="images/multiple-stationaries_2.jpeg" height=auto width="450"></td>
				</tr>
			</table>
			<hr>
			<p>This system will allow you to create new inventory, delete inventory items completely, as well as update the current stock. The pages linked below will lead to the appropriate pages to allow you to manage the inventory</p>
			<br>
			<hr>
		</div>
	</div>

	<div class="center">
		<hr>
		<p>Some of the items that we sell
			<div class="center">
				<table>
					<tr>
						<td><img src="/images/blue-pens.jpeg" height="auto" width="250" alt=""></td>
						<td><img src="/images/black-pens.jpeg" height="auto" width="250"></td>
						<td><img src="/images/colored-pencils.jpeg" height="auto" width="250" alt=""></td>
						<td><img src="/images/correction-fluid.jpeg" height="auto" width="250" alt=""></td>
					</tr>
					<tr>

					</tr>
					<tr>
						<td><img src="/images/eraser.jpeg" height="auto" width="250"></td>
						<td><img src="/images/scissors.jpeg" height="auto" width="250" alt=""></td>
						<td><img src="/images/wooden-ruler.png" alt="" height="auto" width="250"></td>
					</tr>
				</table>
			</div>
		</p>
		<hr>
	</div>
	
	<div>
		<hr>
		<p>Links to the different pages here: </p>
		<a href="view_inventory_webpage.php">View current inventory</a><br>
		<a href="new_inventory_webpage.php">Create new inventory</a><br>
		<a href="update_inventory_webpage.php">Update inventory</a><br>
		<a href="delete_inventory_webpage.php">Delete inventory</a>
		<hr>
	</div>

	<div id="ContactUs" align="center">
		<hr>
		<div>
			<h2>Contact Us</h2>
		</div>
		<table>
			<tr>
				<td><img src="images/multiple-stationaries_3_cover.jpeg" height=auto width="120"></td>
			</tr>
		</table>
		<div><p>Multimedia University, Persiaran Multimedia,<br> 63100 Cyberjaya, Selangor, Malaysia<br>Email: 1181302902@student.mmu.edu.my</p></div>
		<div>
			<h3>Hours</h3>
		</div>
		<div>Weekdays: 9:00am - 6:00pm<br>Saturday: 10:00am - 7:00pm<br>Closed on Sundays</div>
	</div>

	<div id="Copyright" class="center">
		<h5><p>&copy; 2020, Amazon Web Services, Inc. or its Affiliates. All rights reserved.</p></h5>
	</div>
</body>
</html>
