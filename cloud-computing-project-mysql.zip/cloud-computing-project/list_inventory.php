<?php
    // script to generate name of items and inventory levels
    $sql = "SELECT * FROM Inventory_Table";
    $result = $dbconn -> query($dbh, $sql);
    
    if (!$result)
    {
        die("Error in SQL query: " . mysqli_connect_error());
    }

    while ($row = pg_fetch_array($result)) 
    {
        echo "Name of Item: " . $row[0] . "<br />";
        echo "Amount in Inventory: " . $row[1] . "<p />";
    }

    $result -> free_result(); // free memory 

?>