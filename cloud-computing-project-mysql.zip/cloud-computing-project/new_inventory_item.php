<?php
    # $item_name = $_POST[""];
    # $stock_level = $_POST[""];
    $sql = "INSERT INTO Inventory_table VALUES ($item_name, $stock_level)";
    $result = $dbconn -> query($sql);

    if (!$result) 
    {
        die("Error in SQL query: " . mysqli_connect_error());
    }
    
    $result -> free_result();
?>