<?php
    $dbconn = mysqli_connect(localhost, kshore, pass123, main_db);

    $query = "SELECT item_names FROM public.inventory_table";
    $result = $dbconn -> query($query);
    
    if($result->num_rows> 0)
    {
        $options= mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    

?>