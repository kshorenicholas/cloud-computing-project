<?php
    # $item_name = $_POST[""];
    # $stock_level = $_POST[""];
    $sql = "UPDATE Inventory_table SET stock_level = $stock_level WHERE item_name = '$item_name'";
    $result = $dbconn -> query($sql);

    if (!$result) 
    {
        die("Error in SQL query: " . mysqli_connect_error());
    }
    
    $result -> free_result();
?>