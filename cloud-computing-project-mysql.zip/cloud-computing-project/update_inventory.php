<!DOCTYPE html>
<html>
    <head>
        <title>Update Inventory</title>
        <link rel="stylesheet" href="../css/styles.css">
    </head>

    <body>
        <div id="header" class="mainHeader">
            <hr>
            <div class="center">Update Current Inventory</div>
        </div>
        <br>

        <div id="mainContent">
            <hr>
            <div></div>
        </div>

        <div>
            <form action="">
                <br>

                <label for="">Name of Inventory </label>  <!-- add php code to inject list of current items that users can select-->
<!--                 <select name="inventory-names" id="inventory-names">
                    <option value="pencil">pencil</option>
                    <option value="pens">pen</option>
                    <option value="scissor">scissor</option>
                    <option value="eraser">eraser</option>
                    <option value="ruler">ruler</option>
                    <option value="correction liquid">correction liquid</option>
                </select> -->
                
                <br>
                <label for="">Current amount: </label> 
                <output name="current-amount"></output> <!-- add php code to call stock_amount from selected item id, will need to immediately execute when user selects an item above -->

                <br>
                <label for="">New amount: </label>
                <input type="number" inputmode="numeric"> <!-- add php code here that will send data to the database table to be updated, will only run after submit button has been clicked -->
                
            </form>
        </div>

        <br><br>

        <button type="submit">Update Database</button>  <!-- clicking this button send data from "New Amount" label to the database table to be updated -->

        <br><br>
        <a href="view_current_inventory_webpage.php">Check Inventory amounts here</a>
    </body>
</html>