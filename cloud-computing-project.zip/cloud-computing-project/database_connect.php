<?php
    
    $servername = "localhost";
    $database = "main_db";
    $username = "kshore";
    $password = "pass123";

    $dbconn =  mysqli_connect($servername, $username, $password, $database);
?>  
