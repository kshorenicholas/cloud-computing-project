<!DOCTYPE html>
<html>
    <head>
        <title>Create Inventory</title>
        <link rel="stylesheet" href="../css/styles.css">
    </head>

    <body>
        <div id="header" class="mainHeader">
            <hr>
            <div class="center">Create New Inventory</div>
        </div>
        <br>

        <div id="mainContent">
            <hr>
            <div></div>
        </div>

        <div>
            <form method="post">
                <br>
                Name of Inventory: <input type="text" name="new-inventory-name">
                <br>
                Amount: <input type="number" name="new-inventory-amount"> 
                <br>
                <button type="submit" name="add_data_button">Update Database</button>
                
            </form>
        </div>

        <br><br>

        <?php

            if (isset($_POST['add_data_button'])){

                include 'database_connect.php';

                $item_name = $_POST['new-inventory-name'];
                $stock_level = $_POST['new-inventory-amount'];

                $sql = "INSERT INTO inventory_table VALUES ('$item_name', $stock_level)";
                $result = $dbconn->query($sql);

                $dbconn->close();
            }
        ?>
        <br><br>
        <a href="view_inventory_webpage.php">Check Inventory amounts here</a>
    </body>
</html>