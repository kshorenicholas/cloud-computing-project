<?php 
    
    $servername = "localhost";
    $database = "main_db";
    $username = "kshore";
    $password = "pass123";

    $conn = mysqli_connect($servername, $username, $password, $database);

    if ($conn->connect_error){
        die("Connection Failed: " . $conn->connect_error);
    }

    echo "Connected Successfully";
    $conn->close(); 
?>
