<?php
    include 'database_connect.php';

    $query = "SELECT item_name FROM inventory_table";
    $result = $dbconn->query($query);
    $resultCheck = mysqli_num_rows($result);
    if($resultCheck > 0)
    {
        $options=mysqli_fetch_all($result, MYSQLI_ASSOC);
    }
    mysqli_free_result($result);
    $dbconn->close();       
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Update Inventory</title>
        <link rel="stylesheet" href="./css/styles.css">
    </head>

    <body>
        <div id="header" class="mainHeader">
            <hr>
            <div class="center">Update Current Inventory</div>
        </div>
        <br>

        <div id="mainContent">
            <hr>
            <div></div>
        </div>

        <div>
            <form method="post">
                <br>
                <label for="inventory-group">Name of Inventory: </label>
                <select name="item_name">
                    <option>Select Item</option>
                    <?php foreach($options as $option) { ?>
                    <option><?php echo $option['item_name']; ?></option>
                    <?php } ?>
                </select>           
                <br>    
                New Amount: <input name="new_stock_level" type="number" inputmode="numeric"> <!-- add php code here that will send data to the database table to be updated, will only run after submit button has been clicked -->
                <br><br>
                <button name="update_inventory_button" type="submit">Update Database</button>
            </form>
        </div>
        <?php
            if(isset($_POST['update_inventory_button']))
            {
                include 'database_connect.php';

                $item_name = $_POST['item_name'];
                $new_stock_level = $_POST['new_stock_level'];

                $sql = "UPDATE inventory_table SET stock_level='$new_stock_level' WHERE item_name='$item_name'";
                $result = $dbconn -> query($sql);

                $dbconn->close();
            } 
        ?>       

        <br><br>
        <a href="view_inventory_webpage.php">Check Inventory amounts here</a>
    </body>
</html>