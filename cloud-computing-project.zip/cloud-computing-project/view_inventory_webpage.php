<!DOCTYPE html>
<html>
    <head>
        <title>View Inventory</title>
        <link rel="stylesheet" href="./css/styles.css">
    </head>

    <body>
        <div id="header" class="mainHeader">
            <hr>
            <div class="center">View Current Inventory</div>
        </div>
        <br>

        <div id="mainContent">
            <hr>
            <div></div>
        </div>

        <div>
            <form method="post">
                <br>
                <label>Press button to view current inventory: </label>  <!-- php code here to pull inventory names from database table, code can be reused -->

                <button type="submit" name="view_data_button">View Inventory</button>
                <br><br>
            </form>
        </div
        <?php

            if (isset($_POST['view_data_button'])){
                include 'database_connect.php';

                $sql = 'SELECT * FROM inventory_table';
                $result = $dbconn->query($sql);
                // $row = mysqli_fetch_array($result, MYSQLI_BOTH);
                $row_cnt = $result->num_rows;

                $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
                foreach ($rows as $row){
                    echo "Name of Item: " . $row["item_name"] . "<br />";
                    echo "Amount in Inventory: " . $row["stock_level"] . "<p />";
                }

                $result->free_result();

                $dbconn->close();
            }
        ?>

        <br><br>
    </body>
</html>